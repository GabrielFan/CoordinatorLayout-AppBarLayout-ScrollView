package com.gabriel.coordinatorlayout.bean;

/**
 * @author GF
 * @des Bean
 * @date 2018/8/27
 */
public class ScorllviewBean {


    /**
     * ac_id : 77
     * bm_id : 412203
     * bm_name : 黄先生
     * area : 100
     * zx_address : 曹杨路272号
     * appoint_measure_time : 1522425600
     * guwen_name : 吴德强
     * guwen_phone : 13381531215
     * firm_name : test-admin,
     * is_read : 0
     */

    private String ac_id;
    private String bm_id;
    private String bm_name;
    private String area;
    private String zx_address;



    public String getAc_id() {
        return ac_id;
    }

    public void setAc_id(String ac_id) {
        this.ac_id = ac_id;
    }

    public String getBm_id() {
        return bm_id;
    }

    public void setBm_id(String bm_id) {
        this.bm_id = bm_id;
    }

    public String getBm_name() {
        return bm_name;
    }

    public void setBm_name(String bm_name) {
        this.bm_name = bm_name;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getZx_address() {
        return zx_address;
    }

    public void setZx_address(String zx_address) {
        this.zx_address = zx_address;
    }
}
