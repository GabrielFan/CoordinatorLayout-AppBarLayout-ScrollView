package com.gabriel.coordinatorlayout.adapter;

import android.support.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.gabriel.coordinatorlayout.bean.ScorllviewBean;

import java.util.List;

/**
 * @author GF
 * @des 列表适配器
 * @date 2019/1/3
 */
public class CoordinatorAdapter extends BaseQuickAdapter<List<ScorllviewBean>, BaseViewHolder> {

    public CoordinatorAdapter(int layoutResId, @Nullable List<List<ScorllviewBean>> data) {
        super(layoutResId, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, List<ScorllviewBean> item) {

    }
}
