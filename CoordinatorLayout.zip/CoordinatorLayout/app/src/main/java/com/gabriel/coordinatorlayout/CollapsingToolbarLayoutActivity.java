package com.gabriel.coordinatorlayout;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.gabriel.coordinatorlayout.adapter.ScorllviewAdapter;
import com.gabriel.coordinatorlayout.bean.ScorllviewBean;
import com.gabriel.coordinatorlayout.weigth.LoadingDialog;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @author GF
 * @des CollapsingToolbarLayout  悬浮置顶
 * @date 2019/1/3
 */
public class CollapsingToolbarLayoutActivity extends AppCompatActivity {
    @BindView(R.id.edit_owner_id)
    EditText mEditOwnerId;
    @BindView(R.id.arl_baoming_id)
    RelativeLayout mArlBaomingId;
    @BindView(R.id.abl_allocation)
    AppBarLayout mAblAllocation;
    @BindView(R.id.rv_allcation)
    RecyclerView mRvAllcation;
    @BindView(R.id.cdl_allocation)
    CoordinatorLayout mCdlAllocation;
    @BindView(R.id.srl_allcation)
    SmartRefreshLayout mSrlAllcation;
    @BindView(R.id.iv_image)
    ImageView mIvImage;

    private ScorllviewAdapter mAdapter;
    private List<ScorllviewBean> mDate = new ArrayList<>();
    private LoadingDialog mLoadingDialog;
    public int page = 1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collapsingtoolbarayout_layout);
        ButterKnife.bind(this);
        Glide.with(this).load(R.mipmap.timg).into(mIvImage);
        initRecyclerView();
        //SwipeRefreshLayout
        mSrlAllcation.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(RefreshLayout refreshLayout) {
                page = 1;
                refreshLayout.setEnableRefresh(true);//启用刷新
                search(true, false);
            }
        });
        search(true, true);
    }


    /**
     * 初始化RecyclerView
     */
    private void initRecyclerView() {
        mAdapter = new ScorllviewAdapter(R.layout.items_scorllview_list, mDate);
        mRvAllcation.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                //时常修复滑动不顺畅
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    int firstVisiblePosition = new LinearLayoutManager(CollapsingToolbarLayoutActivity.this)
                            .findFirstCompletelyVisibleItemPosition();
                    if (firstVisiblePosition == 0) {
                        mAblAllocation.setExpanded(true, true);
                    }
                }

            }
        });
        mRvAllcation.setLayoutManager(new LinearLayoutManager(this) {
            @Override
            public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
                try {
                    super.onLayoutChildren(recycler, state);
                } catch (IndexOutOfBoundsException e) {
                    e.printStackTrace();
                }

            }
        });
        mRvAllcation.setAdapter(mAdapter);
        mAdapter.setOnLoadMoreListener(new BaseQuickAdapter.RequestLoadMoreListener() {
            @Override
            public void onLoadMoreRequested() {
                page++;
                mAdapter.setEnableLoadMore(true);
                search(false, true);
            }
        });
    }

    /**
     * 加载数据
     *
     * @param b
     * @param b1
     */
    private void search(boolean b, boolean b1) {
        if (b && b1) {
            if (mLoadingDialog == null) {
                mLoadingDialog = new LoadingDialog(this);
            }
            mLoadingDialog.show();
        }
        if (b) {
            mDate.clear();
        }
        for (int i = 0; i < 20 * page; i++) {
            ScorllviewBean bean = new ScorllviewBean();
            bean.setAc_id(String.valueOf(i + (int) (1 + Math.random() * (10 - 1 + 1))));
            bean.setBm_name(i + "Gabriel_Fan");
            bean.setZx_address("上海市普陀区武宁路");
            bean.setArea("上海xxx信息科技有限公司");
            mDate.add(bean);
        }
        if (b && b1) {
            mLoadingDialog.dismiss();
        }
        if (b1) {
            mAdapter.loadMoreEnd();
        }
        mAdapter.notifyDataSetChanged();
        mSrlAllcation.finishRefresh();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mLoadingDialog != null) {
            mLoadingDialog.dismiss();
        }
    }
}
